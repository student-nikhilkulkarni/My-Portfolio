import { motion } from "motion/react";
import { 
  Github, 
  Mail, 
  Phone, 
  ExternalLink, 
  Code2, 
  Database, 
  Cpu, 
  Terminal, 
  Layers, 
  Award, 
  ChevronRight,
  Gamepad2,
  Library,
  UserCircle,
  Calculator,
  Music
} from "lucide-react";
import FlipCard from "./components/FlipCard";

const SKILLS = [
  { name: "HTML5", icon: <Code2 className="w-4 h-4" />, color: "text-blue-400" },
  { name: "CSS3", icon: <Layers className="w-4 h-4" />, color: "text-purple-400" },
  { name: "JavaScript", icon: <Terminal className="w-4 h-4" />, color: "text-yellow-400" },
  { name: "Java", icon: <Cpu className="w-4 h-4" />, color: "text-blue-500" },
  { name: "MySQL", icon: <Database className="w-4 h-4" />, color: "text-purple-500" },
  { name: "Git", icon: <Github className="w-4 h-4" />, color: "text-yellow-500" },
  { name: "GitHub", icon: <Github className="w-4 h-4" />, color: "text-blue-400" },
  { name: "Arduino", icon: <Cpu className="w-4 h-4" />, color: "text-purple-400" },
];

const PROJECTS = [
  {
    title: "Spotify Clone",
    description: "Dynamic music streaming web app replicating core features like playlist creation and search.",
    tech: ["HTML", "CSS", "JavaScript"],
    icon: <Music className="w-8 h-8 text-purple-500" />,
    details: "Implemented song browsing, playback controls, and a responsive interface for all devices.",
    accent: "bg-purple-600",
    glow: "group-hover:border-purple-500/50"
  },
  {
    title: "Snake Game",
    description: "Interactive arcade game built with Canvas API and vanilla JavaScript.",
    tech: ["HTML", "CSS", "JS", "Canvas"],
    icon: <Gamepad2 className="w-8 h-8 text-yellow-500" />,
    details: "Features collision detection, food generation, and real-time score tracking.",
    accent: "bg-yellow-500",
    glow: "group-hover:border-yellow-500/50"
  },
  {
    title: "Library Management",
    description: "Full-stack system for managing book inventory and member records.",
    tech: ["MySQL", "Java", "JDBC"],
    icon: <Library className="w-8 h-8 text-blue-500" />,
    details: "Designed efficient database schemas for book issue/return and inventory tracking.",
    accent: "bg-blue-600",
    glow: "group-hover:border-blue-500/50"
  },
  {
    title: "Tic Tac Toe",
    description: "Clean, interactive 2-player game with win detection and turn tracking.",
    tech: ["HTML", "CSS", "JavaScript"],
    icon: <Gamepad2 className="w-8 h-8 text-purple-500" />,
    details: "Leveraged CSS Grid for a responsive 3x3 layout and JS for game logic.",
    accent: "bg-purple-600",
    glow: "group-hover:border-purple-500/50"
  },
  {
    title: "Simple Calculator",
    description: "Functional calculator performing complex arithmetic operations.",
    tech: ["HTML", "CSS", "JavaScript"],
    icon: <Calculator className="w-8 h-8 text-yellow-500" />,
    details: "Handles input validation and real-time result display with error handling.",
    accent: "bg-yellow-500",
    glow: "group-hover:border-yellow-500/50"
  },
  {
    title: "Digital Notice Board",
    description: "Hardware-software integration using Arduino for real-time announcements.",
    tech: ["Arduino", "C++", "Sensors"],
    icon: <Cpu className="w-8 h-8 text-blue-500" />,
    details: "Built during college to digitize notice distribution using embedded systems.",
    accent: "bg-blue-600",
    glow: "group-hover:border-blue-500/50"
  }
];

const CERTIFICATIONS = [
  {
    title: "IEEE International Symposium",
    org: "Cloud, Quantum & AI",
    date: "Jun 2024 - Jul 2024",
    color: "border-blue-500/20"
  },
  {
    title: "AI & Generative AI Workshop",
    org: "MNIST CNN, Gemini, Grok",
    date: "Mar 2025",
    color: "border-purple-500/20"
  },
  {
    title: "3D Printing Training",
    org: "Kritika Technical Academy",
    date: "Jul 2023",
    color: "border-yellow-500/20"
  }
];

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 selection:bg-purple-500/30">
      {/* Background Decor */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-purple-600/10 blur-[120px] rounded-full animate-pulse-slow" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-600/10 blur-[120px] rounded-full animate-pulse-slow" style={{ animationDelay: '-2s' }} />
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-yellow-500/5 blur-[100px] rounded-full animate-pulse-slow" style={{ animationDelay: '-4s' }} />
      </div>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-12 lg:py-24">
        {/* Hero Section */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-24">
          <div className="lg:col-span-8 flex flex-col justify-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-block px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-mono mb-6">
                AVAILABLE FOR OPPORTUNITIES
              </span>
              <h1 className="text-6xl lg:text-8xl font-display font-bold tracking-tight mb-6">
                NIKHIL <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-yellow-400">KULKARNI</span>
              </h1>
              <p className="text-xl text-zinc-400 max-w-2xl leading-relaxed mb-8">
                A passionate developer skilled in <span className="text-blue-400">Java</span>, <span className="text-purple-400">HTML/CSS</span>, and <span className="text-yellow-400">JavaScript</span>. 
                Focused on building innovative solutions and driving collaborative success through technical excellence.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <a 
                  href="mailto:nikhilkulkarninikhil60@gmail.com"
                  className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold hover:shadow-[0_0_20px_rgba(147,51,234,0.3)] transition-all"
                >
                  <Mail className="w-4 h-4" />
                  Contact Me
                </a>
                <a 
                  href="https://github.com/nikhilkulkarni60" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-6 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 hover:border-blue-500/50 transition-colors"
                >
                  <Github className="w-4 h-4" />
                  GitHub Profile
                </a>
                <a 
                  href="tel:+917760101285"
                  className="flex items-center gap-2 px-6 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 hover:border-yellow-500/50 transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  +91 7760101285
                </a>
              </div>
            </motion.div>
          </div>

          <div className="lg:col-span-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="h-full min-h-[300px] rounded-3xl bg-zinc-900/50 border border-zinc-800 p-8 flex flex-col justify-between overflow-hidden relative group hover:border-blue-500/30 transition-colors"
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Terminal className="w-32 h-32 text-blue-500" />
              </div>
              <div>
                <h3 className="text-sm font-mono text-blue-400 mb-4 uppercase tracking-widest">Education</h3>
                <p className="text-xl font-display font-semibold mb-1">Guru Nanak Dev Engineering College</p>
                <p className="text-zinc-400">Bachelor of Engineering</p>
                <p className="text-zinc-500 text-sm mt-2">2022 — Present | Bidar, KA</p>
              </div>
              <div className="mt-8 pt-8 border-t border-zinc-800">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-zinc-500">Status</span>
                  <span className="text-yellow-500 font-mono">Active Student</span>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Skills Bento */}
        <section className="mb-24">
          <div className="flex items-center gap-4 mb-12">
            <h2 className="text-3xl font-display font-bold">Technical Arsenal</h2>
            <div className="h-px flex-1 bg-zinc-800" />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {SKILLS.map((skill, idx) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                viewport={{ once: true }}
                className="p-4 rounded-2xl bg-zinc-900/30 border border-zinc-800 flex flex-col items-center justify-center gap-3 hover:border-zinc-700 transition-colors group"
              >
                <div className={`p-2 rounded-lg bg-zinc-800 ${skill.color} transition-colors`}>
                  {skill.icon}
                </div>
                <span className="text-xs font-mono text-zinc-500 group-hover:text-zinc-300">{skill.name}</span>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Projects Flip Cards */}
        <section className="mb-24">
          <div className="flex items-center gap-4 mb-12">
            <h2 className="text-3xl font-display font-bold">Featured Projects</h2>
            <div className="h-px flex-1 bg-zinc-800" />
            <span className="text-zinc-500 text-sm font-mono">HOVER TO FLIP</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {PROJECTS.map((project, idx) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="h-[320px]"
              >
                <FlipCard
                  front={
                    <div className={`w-full h-full p-8 rounded-3xl bg-zinc-900 border border-zinc-800 flex flex-col justify-between group transition-all duration-300 ${project.glow}`}>
                      <div>
                        <div className="mb-6">{project.icon}</div>
                        <h3 className="text-2xl font-display font-bold mb-2">{project.title}</h3>
                        <p className="text-zinc-400 text-sm line-clamp-3">{project.description}</p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {project.tech.map(t => (
                          <span key={t} className="text-[10px] font-mono px-2 py-1 rounded bg-zinc-800 text-zinc-500 uppercase">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  }
                  back={
                    <div className={`w-full h-full p-8 rounded-3xl ${project.accent} text-white flex flex-col justify-between shadow-xl`}>
                      <div>
                        <h3 className="text-2xl font-display font-bold mb-4">Project Details</h3>
                        <p className="font-medium leading-relaxed opacity-90">{project.details}</p>
                      </div>
                      <div className="flex items-center gap-2 font-bold text-sm">
                        View Source <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  }
                />
              </motion.div>
            ))}
          </div>
        </section>

        {/* Certifications & Awards */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-24">
          <div>
            <div className="flex items-center gap-4 mb-8">
              <h2 className="text-2xl font-display font-bold">Certifications</h2>
              <Award className="w-5 h-5 text-yellow-500" />
            </div>
            <div className="space-y-4">
              {CERTIFICATIONS.map((cert, idx) => (
                <div 
                  key={idx}
                  className={`p-6 rounded-2xl bg-zinc-900/50 border ${cert.color} hover:bg-zinc-900 transition-colors`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-zinc-100">{cert.title}</h4>
                    <span className="text-xs font-mono text-zinc-500">{cert.date}</span>
                  </div>
                  <p className="text-sm text-zinc-400">{cert.org}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col justify-center p-12 rounded-[40px] bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-yellow-500/5 border border-zinc-800 relative overflow-hidden group">
            <div className="absolute -right-12 -bottom-12 opacity-5 group-hover:opacity-10 transition-opacity">
              <UserCircle className="w-64 h-64 text-purple-500" />
            </div>
            <h2 className="text-4xl font-display font-bold mb-6">Let's build something <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">extraordinary</span>.</h2>
            <p className="text-zinc-400 mb-8 leading-relaxed">
              I am always looking for new challenges and opportunities to grow as a developer. 
              If you have a project in mind or just want to chat, feel free to reach out.
            </p>
            <div className="flex gap-4">
              <a href="https://github.com/nikhilkulkarni60" target="_blank" rel="noopener noreferrer" className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-blue-400 transition-colors">
                <Github className="w-6 h-6" />
              </a>
              <a href="mailto:nikhilkulkarninikhil60@gmail.com" className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-purple-400 transition-colors">
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="pt-12 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-zinc-500 text-sm font-mono">
            © 2024 NIKHIL KULKARNI. ALL RIGHTS RESERVED.
          </p>
          <div className="flex gap-8 text-xs font-mono text-zinc-500 uppercase tracking-widest">
            <a href="#" className="hover:text-blue-400 transition-colors">LinkedIn</a>
            <a href="https://github.com/nikhilkulkarni60" target="_blank" rel="noopener noreferrer" className="hover:text-purple-400 transition-colors">GitHub</a>
            <a href="#" className="hover:text-yellow-400 transition-colors">Resume</a>
          </div>
        </footer>
      </main>
    </div>
  );
}
